const cacheName = 'verite-defi-cache-v1';
const filesToCache = [
  './index.html',
  './manifest.json',
  'https://i.imgur.com/5hH6vO8.png',
  'https://www.soundjay.com/button/sounds/button-16.mp3',
  'https://www.soundjay.com/button/sounds/button-09.mp3'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(cacheName).then(cache => cache.addAll(filesToCache))
  );
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(response => response || fetch(e.request))
  );
});
